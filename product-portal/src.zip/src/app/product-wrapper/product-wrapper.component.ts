import { Component, OnInit, ViewChild } from '@angular/core';

@Component({
  selector: 'app-product-wrapper',
  templateUrl: './product-wrapper.component.html',
  styleUrls: ['./product-wrapper.component.css']
})
export class ProductWrapperComponent implements OnInit {

  

  constructor() { }

  ngOnInit(): void {
  }

}
